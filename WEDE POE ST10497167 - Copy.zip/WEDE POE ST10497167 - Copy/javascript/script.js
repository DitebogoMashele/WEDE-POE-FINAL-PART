document.getElementById("bookingForm").addEventListener("submit", function(event) {
    event.preventDefault();

    let name = document.getElementById("fullname").value.trim();
    let email = document.getElementById("email").value.trim();
    let service = document.getElementById("service").value;
    let day = document.getElementById("day").value;

    // Validation
    if (name === "" || email === "" || service === "" || day === "") {
        alert("Please fill in all the required fields.");
        return;
    }

    // Show updated success message
    document.getElementById("successMessage").textContent =
        "✅ Your information has been successfully captured!";

    document.getElementById("successMessage").style.display = "block";

    // Reset form
    document.getElementById("bookingForm").reset();
});
